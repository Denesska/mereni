CREATE VIEW total AS
  SELECT
    `tb`.`surname`                                              AS `surname`,
    `tb`.`name`                                                 AS `name`,
    `cozagro_db`.`lichidare`.`id`                               AS `id`,
    `tb`.`id_angajat`                                           AS `id_angajat`,
    `cozagro_db`.`lichidare`.`salarii`                          AS `salarii`,
    `cozagro_db`.`lichidare`.`creante`                          AS `creante`,
    `cozagro_db`.`lichidare`.`platit`                           AS `platit`,
    `cozagro_db`.`lichidare`.`rest`                             AS `rest`,
    date_format(`cozagro_db`.`lichidare`.`data`, '%a %d %m %Y') AS `dat_db`,
    `tb`.`totalP`                                               AS `totalP`,
    `tb`.`totalC`                                               AS `totalC`,
    `tb`.`totalS`                                               AS `totalS`,
    `tb`.`totalR`                                               AS `totalR`
  FROM (`cozagro_db`.`lichidare`
    JOIN `cozagro_db`.`total_bani` `tb` ON ((`cozagro_db`.`lichidare`.`id_angajat` = `tb`.`id_angajat`)))
  WHERE (NOT (exists(SELECT 1
                     FROM `cozagro_db`.`lichidare` `l2`
                     WHERE ((`l2`.`id_angajat` = `cozagro_db`.`lichidare`.`id_angajat`) AND
                            (`l2`.`id` > `cozagro_db`.`lichidare`.`id`)))));
