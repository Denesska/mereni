CREATE VIEW total_bani AS
  SELECT
    `an`.`surname`      AS `surname`,
    `an`.`name`         AS `name`,
    `li`.`id_angajat`   AS `id_angajat`,
    sum(`li`.`platit`)  AS `totalP`,
    sum(`li`.`creante`) AS `totalC`,
    sum(`li`.`salarii`) AS `totalS`,
    sum(`li`.`rest`)    AS `totalR`
  FROM (`cozagro_db`.`lichidare` `li`
    JOIN `cozagro_db`.`angajati` `an` ON ((`li`.`id_angajat` = `an`.`id`)))
  GROUP BY `li`.`id_angajat`;
